# Contributors

Created by Pavel Malai ([@flagman](https://github.com/flagman))

With the pull requests, bug reports and ideas of, most first (a pull request counts once, however many
changes thank it):

- [@visualpharm](https://github.com/visualpharm): 43 reports and ideas
- [@ManyLattice](https://github.com/ManyLattice): 7 reports and ideas
- [@kalimullin](https://github.com/kalimullin): 2 pull requests, 4 reports and ideas
- [@GreatMedivack](https://github.com/GreatMedivack): 6 reports and ideas
- [@Eugenius-S](https://github.com/Eugenius-S): 4 reports and ideas
- [@Enwimo](https://github.com/Enwimo): 1 report or idea
- [@login](https://github.com/login): 1 report or idea
- [@Scremliss](https://github.com/Scremliss): 1 report or idea

Built from the thanks of the changelog at every release by `tools/contributors.py`; not edited by hand.
