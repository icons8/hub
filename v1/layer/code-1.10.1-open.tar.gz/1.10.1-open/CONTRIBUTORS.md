# Contributors

Created by Pavel Malai ([@flagman](https://github.com/flagman))

With the pull requests, bug reports and ideas of, most first (a pull request counts once, however many
changes thank it):

- [@visualpharm](https://github.com/visualpharm): 61 reports and ideas
- [@kalimullin](https://github.com/kalimullin): 2 pull requests, 17 reports and ideas
- [@GreatMedivack](https://github.com/GreatMedivack): 12 reports and ideas
- [@Eugenius-S](https://github.com/Eugenius-S): 9 reports and ideas
- [@ManyLattice](https://github.com/ManyLattice): 9 reports and ideas
- [@Enwimo](https://github.com/Enwimo): 5 reports and ideas
- [@DeValar](https://github.com/DeValar): 1 report or idea
- [@elenalo91](https://github.com/elenalo91): 1 report or idea
- [@login](https://github.com/login): 1 report or idea
- [@sanchopanda](https://github.com/sanchopanda): 1 report or idea
- [@Scremliss](https://github.com/Scremliss): 1 report or idea
- [@summers-julia](https://github.com/summers-julia): 1 report or idea
- [@x6y9kax](https://github.com/x6y9kax): 1 report or idea

Built from the thanks of the changelog at every release by `tools/contributors.py`; not edited by hand.
